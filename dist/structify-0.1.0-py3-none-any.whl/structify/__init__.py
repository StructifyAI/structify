__version__ = "0.1.0"
__author__ = 'Alex Reichenbach'
__credits__ = 'Structify'